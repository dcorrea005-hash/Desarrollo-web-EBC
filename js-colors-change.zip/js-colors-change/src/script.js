//Desafío 1: cambiar el título.getElementById //

document.getElementById("btn-titulo").addEventListener("click",()=>
{
  const titulo=
        document.getElementById("titulo")
  titulo.textContent = "¡El desafio de Dani!";
});

//Desafío 2: cambio de color de las cajas get.ElementsByClassName//

document.getElementById("btn-cajas").addEventListener("click",()=>
{
 const cajas=
       document.getElementsByClassName("caja");
  for(let i = 0; i < cajas.length; i++)
    {
      cajas[i].style.backgroundColor="#DA9CFF";
    }
});

//Desafío 3: cambio de color de la primera caja querySelector//

document.getElementById("btn-primera").addEventListener("click",()=>
  {
  const primeracaja =
        document.querySelector(".caja");
  primeracaja.style.backgroundColor = "#FFABE4";
});

//Desafío 4: cambio de color de los bordes querySelectorAll()//

document.getElementById("btn-bordes").addEventListener("click",()=>
{
  const cajas=
        document.querySelectorAll(".caja");
      cajas.forEach(caja=>{
        caja.style.border="2px solid #D6BB0B"
      });
});
    