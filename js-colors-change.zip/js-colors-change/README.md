# JS-colors change

A Pen created on CodePen.

Original URL: [https://codepen.io/DANIELA-CORREAOSORNIO/pen/LEpqejP](https://codepen.io/DANIELA-CORREAOSORNIO/pen/LEpqejP).

