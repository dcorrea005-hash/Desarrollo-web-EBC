# Album JS

A Pen created on CodePen.

Original URL: [https://codepen.io/DANIELA-CORREAOSORNIO/pen/jEbRymN](https://codepen.io/DANIELA-CORREAOSORNIO/pen/jEbRymN).

